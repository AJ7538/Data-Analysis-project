import pandas as pd

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df['highest_yearly_earnings'] = pd.to_numeric(df['highest_yearly_earnings'], errors='coerce')
df_clean = df.dropna(subset=['highest_yearly_earnings'])

Q1 = df_clean['highest_yearly_earnings'].quantile(0.25)
Q3 = df_clean['highest_yearly_earnings'].quantile(0.75)
IQR = Q3 - Q1
upper_bound = Q3 + 1.5 * IQR
outliers = df_clean[df_clean['highest_yearly_earnings'] > upper_bound]

print(f"Upper bound for outliers: {round(upper_bound):,} USD\n")
print("YouTube Channels with Outlier Yearly Earnings:\n")
print(outliers[['Youtuber', 'category', 'highest_yearly_earnings']].sort_values(by='highest_yearly_earnings', ascending=False))
