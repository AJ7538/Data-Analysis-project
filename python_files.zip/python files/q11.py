import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df_clean = df.dropna(subset=['Country', 'Gross tertiary education enrollment (%)'])
channel_counts = df_clean['Country'].value_counts().rename_axis('Country').reset_index(name='Channel_Count')
edu_avg = df_clean.groupby('Country')['Gross tertiary education enrollment (%)'].mean().reset_index()
merged = pd.merge(channel_counts, edu_avg, on='Country')

plt.figure(figsize=(10, 6))
plt.scatter(merged['Gross tertiary education enrollment (%)'], merged['Channel_Count'], color='purple')
plt.title('Tertiary Education Enrollment vs YouTube Channel Count per Country')
plt.xlabel('Gross Tertiary Education Enrollment (%)')
plt.ylabel('Number of YouTube Channels')
plt.grid(True)
plt.tight_layout()
plt.show()

correlation = merged['Gross tertiary education enrollment (%)'].corr(merged['Channel_Count'])
print(f"Correlation coefficient: {correlation:.2f}")

