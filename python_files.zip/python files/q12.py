import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df_clean = df.dropna(subset=['Country', 'Unemployment rate'])
channel_counts = df_clean['Country'].value_counts().head(10)
top_countries = channel_counts.index.tolist()
top_df = df_clean[df_clean['Country'].isin(top_countries)]
avg_unemployment = top_df.groupby('Country')['Unemployment rate'].mean().sort_values(ascending=False)

plt.figure(figsize=(12, 6))
avg_unemployment.plot(kind='bar', color='coral')

plt.title('Average Unemployment Rate in Top 10 Countries by YouTube Channel Count')
plt.ylabel('Unemployment Rate (%)')
plt.xlabel('Country')
plt.grid(axis='y', linestyle='--', linewidth=0.5)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
