import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df['created_year'] = pd.to_numeric(df['created_year'], errors='coerce')
df = df.dropna(subset=['created_year'])

channel_trend = df['created_year'].value_counts().sort_index()
channel_trend = channel_trend[channel_trend.index >= 2000]

plt.figure(figsize=(12, 3))
plt.plot(channel_trend.index, channel_trend.values, marker='o', linestyle='-', color='teal')

plt.title('Trend of YouTube Channel Creations Over the Years')
plt.xlabel('Year')
plt.ylabel('Number of Channels Created')
plt.grid(True)
plt.xticks(rotation=45)

ax = plt.gca()
ax.xaxis.set_major_locator(MaxNLocator(integer=True))
ax.yaxis.set_major_locator(MaxNLocator(integer=True))

plt.tight_layout()
plt.show()
