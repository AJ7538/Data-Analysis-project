import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import pearsonr

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df_clean = df[['Country', 'subscribers_for_last_30_days', 'Unemployment rate']].dropna()
df_clean['subscribers_for_last_30_days'] = pd.to_numeric(df_clean['subscribers_for_last_30_days'], errors='coerce')
df_clean['Unemployment rate'] = pd.to_numeric(df_clean['Unemployment rate'], errors='coerce')
df_clean = df_clean.dropna()
grouped = df_clean.groupby('Country').agg({
    'subscribers_for_last_30_days': 'mean',
    'Unemployment rate': 'mean'
}).reset_index()

corr, _ = pearsonr(grouped['subscribers_for_last_30_days'], grouped['Unemployment rate'])
print(f"Pearson correlation: {corr:.2f}")

plt.figure(figsize=(10,6))
plt.scatter(grouped['Unemployment rate'], grouped['subscribers_for_last_30_days'] / 100000, color='mediumseagreen')
plt.title('Correlation Between Unemployment Rate and Subscribers Gained (Last 30 Days)')
plt.xlabel('Unemployment Rate (%)')
plt.ylabel('Avg Subscribers Gained (in 100k)')
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
