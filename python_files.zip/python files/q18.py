import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df_clean = df[['channel_type', 'video_views_for_the_last_30_days']].dropna()
df_clean['video_views_for_the_last_30_days'] = pd.to_numeric(
    df_clean['video_views_for_the_last_30_days'], errors='coerce'
)
df_clean = df_clean.dropna()
df_clean = df_clean[df_clean['video_views_for_the_last_30_days'] > 0]

grouped = df_clean.groupby('channel_type').agg({
    'video_views_for_the_last_30_days': 'mean',
    'channel_type': 'count'
}).rename(columns={
    'video_views_for_the_last_30_days': 'Average Views (Last 30 Days)',
    'channel_type': 'Channel Count'
}).reset_index()
grouped = grouped.sort_values('Average Views (Last 30 Days)', ascending=False)
fig, ax1 = plt.subplots(figsize=(14, 6))

ax1.bar(grouped['channel_type'], grouped['Channel Count'], color='skyblue', label='Channel Count')
ax1.set_xlabel('Channel Type')
ax1.set_ylabel('Channel Count', color='skyblue')
ax1.tick_params(axis='y', labelcolor='skyblue')
ax1.set_xticklabels(grouped['channel_type'], rotation=45, ha='right')

ax2 = ax1.twinx()
ax2.plot(grouped['channel_type'], grouped['Average Views (Last 30 Days)'] / 1e6, color='darkorange', marker='o', label='Avg Views (in Millions)')
ax2.set_ylabel('Average Views (Last 30 Days) [in Millions]', color='darkorange')
ax2.tick_params(axis='y', labelcolor='darkorange')

plt.title('Channel Type: Count vs Avg Views (Last 30 Days)')
plt.grid(axis='y', linestyle='--', alpha=0.4)
fig.tight_layout()
plt.show()
