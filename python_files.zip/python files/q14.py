import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df_clean = df.dropna(subset=['Latitude', 'Longitude'])

plt.figure(figsize=(12, 6))
plt.scatter(df_clean['Longitude'], df_clean['Latitude'], alpha=0.5, s=30, color='purple')

plt.title('Geographic Distribution of YouTube Channels')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
