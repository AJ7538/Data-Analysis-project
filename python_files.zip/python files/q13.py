import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df_clean = df.dropna(subset=['Country', 'Urban_population'])
df_clean['Country'] = df_clean['Country'].str.strip().str.title()
urban_pop_by_country = (
    df_clean.groupby('Country')['Urban_population']
    .mean()
    .round(2)
    .sort_values(ascending=True)
)
plt.figure(figsize=(12, 20)) 
urban_pop_by_country.plot(kind='barh', color='skyblue')

plt.title('Average Urban Population % by Country with YouTube Channels')
plt.xlabel('Urban Population (%)')
plt.ylabel('Country')
plt.grid(axis='x', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()
