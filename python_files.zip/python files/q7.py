import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df['lowest_monthly_earnings'] = pd.to_numeric(df['lowest_monthly_earnings'], errors='coerce')
df['highest_monthly_earnings'] = pd.to_numeric(df['highest_monthly_earnings'], errors='coerce')
df_clean = df.dropna(subset=['category', 'lowest_monthly_earnings', 'highest_monthly_earnings'])

monthly_earnings = df_clean.groupby('category')[['lowest_monthly_earnings', 'highest_monthly_earnings']].mean()
monthly_earnings = (monthly_earnings / 1000).round(1)  # Divide by 1000 and round to 1 decimal place
monthly_earnings_sorted = monthly_earnings.sort_values(by='highest_monthly_earnings', ascending=False)
monthly_earnings_sorted.plot(kind='bar', figsize=(12, 6), color=['skyblue', 'orange'])

plt.title('Average Monthly Earnings by Category (in Thousands)')
plt.xlabel('Category')
plt.ylabel('Earnings (in $1,000s)')
plt.xticks(rotation=45, ha='right')
plt.legend(['Lowest Monthly Earnings', 'Highest Monthly Earnings'])
plt.grid(True, axis='y')
plt.tight_layout()
plt.show()
