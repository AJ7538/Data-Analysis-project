import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df['subscribers_for_last_30_days'] = pd.to_numeric(df['subscribers_for_last_30_days'], errors='coerce')
df_clean = df.dropna(subset=['category', 'subscribers_for_last_30_days'])

sub_trend = df_clean.groupby('category')['subscribers_for_last_30_days'].mean()
sub_trend = (sub_trend / 1000).round(1)

sub_trend_sorted = sub_trend.sort_values(ascending=False)

plt.figure(figsize=(12, 6))
sub_trend_sorted.plot(kind='bar', color='mediumseagreen')

plt.title('Average Subscribers Gained in Last 30 Days by Category (in Thousands)')
plt.xlabel('Category')
plt.ylabel('Subscribers Gained (in 1,000s)')
plt.xticks(rotation=45, ha='right')
plt.grid(True, axis='y')
plt.tight_layout()
plt.show()
