import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import linregress

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df_clean = df.dropna(subset=['subscribers', 'Population', 'Country'])
country_group = df_clean.groupby('Country').agg({
    'subscribers': 'sum',
    'Population': 'mean'
}).reset_index()
country_group = country_group[(country_group['subscribers'] > 0) & (country_group['Population'] > 0)]
country_group['log_subs'] = np.log10(country_group['subscribers'])
country_group['log_pop'] = np.log10(country_group['Population'])

slope, intercept, r_value, _, _ = linregress(country_group['log_pop'], country_group['log_subs'])

plt.figure(figsize=(10, 6))
plt.scatter(country_group['log_pop'], country_group['log_subs'], color='steelblue', alpha=0.7, label='Country Data')

x_vals = np.array(plt.gca().get_xlim())
y_vals = intercept + slope * x_vals
plt.plot(x_vals, y_vals, '--', color='darkred', label=f'Trendline (r = {r_value:.2f})')

plt.xlabel('Country Population(log10)')
plt.ylabel('Total Subscribers(log10)')
plt.title('Correlation Between Country Population and YouTube Subscribers')
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()
plt.tight_layout()
plt.show()
