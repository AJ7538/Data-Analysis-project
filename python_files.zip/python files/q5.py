import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
distribution = pd.crosstab(df['category'], df['channel_type'])


plt.figure(figsize=(14, 7))
distribution.plot(kind='bar', stacked=True, colormap='Set3')

plt.title('Distribution of Channel Types Across Categories')
plt.xlabel('Category')
plt.ylabel('Number of Channels')
plt.xticks(rotation=45, ha='right')
plt.legend(title='Channel Type', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()


plt.show()

