import pandas as pd
df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
category_avg = df.groupby('category')['subscribers'].mean()
category_avg_sorted = category_avg.sort_values(ascending=False)

print("Category with the highest average subscribers:")
print(category_avg_sorted.head(1))
