import pandas as pd
df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')

df.sort_values(by='subscribers', ascending=False)
print(df.head(10))
