import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from datetime import datetime

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df.columns = df.columns.str.strip()
df['subscribers'] = pd.to_numeric(df['subscribers'], errors='coerce')
df['created_year'] = pd.to_numeric(df['created_year'], errors='coerce')
df = df.dropna(subset=['subscribers', 'created_year'])
df = df[(df['created_year'] >= 2006) & (df['subscribers'] > 0)]

current_year = datetime.now().year
df['years_since_creation'] = current_year - df['created_year']
df = df[df['years_since_creation'] > 0]
df['months_since_creation'] = df['years_since_creation'] * 12
df['subs_per_month'] = df['subscribers'] / df['months_since_creation']
overall_avg = df['subs_per_month'].mean()

plt.figure(figsize=(12, 6))
plt.hist(df['subs_per_month'], bins=100, color='#4C72B0', edgecolor='black', log=True)
plt.gca().xaxis.set_major_formatter(FuncFormatter(lambda x, _: f'{int(x/1000)}K'))
plt.axvline(overall_avg, color='crimson', linestyle='--', linewidth=2, label=f'Avg ≈ {overall_avg:,.0f}')

plt.title('Subscribers Gained Per Month(approx value only)', fontsize=14, fontweight='bold')
plt.xlabel('Subscribers per Month', fontsize=12)
plt.ylabel('Number of Channels (log scale)', fontsize=12)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.4)
plt.tight_layout()
plt.show()
