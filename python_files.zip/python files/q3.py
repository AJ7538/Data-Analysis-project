import pandas as pd

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
avg_uploads = df.groupby('category')['uploads'].mean().round(0).astype(int)
avg_uploads_sorted = avg_uploads.sort_values(ascending=False)

print("Average number of uploads per category (rounded):")
print(avg_uploads_sorted)
