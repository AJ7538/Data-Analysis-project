import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')

df_clean = df.dropna(subset=['subscribers', 'video views'])
df_clean = df_clean[(df_clean['subscribers'] > 0) & (df_clean['video views'] > 0)]

correlation = df_clean['subscribers'].corr(df_clean['video views'])
print(f"Correlation between subscribers and video views: {correlation:.2f}")

plt.figure(figsize=(10, 6))
sns.scatterplot(data=df_clean, x='subscribers', y='video views', alpha=0.6, color='purple', edgecolor=None)

plt.xscale('log')
plt.yscale('log')

plt.title('Correlation Between Subscribers and Video Views')
plt.xlabel('Subscribers (log scale)')
plt.ylabel('Video Views (log scale)')
plt.grid(True)
plt.tight_layout()

plt.show()

