import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
df_clean = df.dropna(subset=['Country', 'Population'])
channel_counts = df_clean['Country'].value_counts().head(10)
population_data = df_clean[df_clean['Country'].isin(channel_counts.index)][['Country', 'Population']]
population_data = population_data.drop_duplicates(subset='Country')

merged = pd.DataFrame({
    'Country': channel_counts.index,
    'YouTube Channels': channel_counts.values
})
merged = pd.merge(merged, population_data, on='Country')
merged['Log Population'] = np.log10(merged['Population'])
fig, ax1 = plt.subplots(figsize=(12, 6))

ax1.bar(merged['Country'], merged['YouTube Channels'], color='steelblue', label='YouTube Channels')
ax1.set_xlabel('Country')
ax1.set_ylabel('YouTube Channels', color='steelblue')
ax1.tick_params(axis='y', labelcolor='steelblue')
ax1.set_xticklabels(merged['Country'], rotation=45)

ax2 = ax1.twinx()
ax2.plot(merged['Country'], merged['Log Population'], color='darkorange', marker='o', linewidth=2, label='Log10(Population)')
ax2.set_ylabel('Log10 of Population', color='darkorange')
ax2.tick_params(axis='y', labelcolor='darkorange')

plt.title('Top 10 Countries by YouTube Channels vs Log10(Population)')
fig.tight_layout()
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.show()
