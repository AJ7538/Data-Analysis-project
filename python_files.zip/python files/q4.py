import pandas as pd

df = pd.read_csv("Global YouTube Statistics.csv", encoding='latin1')
top_countries = df['Country'].value_counts().head()

print("Top 5 countries with the highest number of YouTube channels:")
print(top_countries)
